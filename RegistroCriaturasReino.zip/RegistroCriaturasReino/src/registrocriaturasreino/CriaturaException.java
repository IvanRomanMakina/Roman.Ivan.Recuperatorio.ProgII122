package registrocriaturasreino;

public class CriaturaException extends Exception {
    public CriaturaException(String mensaje) {
        super(mensaje);
    }
}