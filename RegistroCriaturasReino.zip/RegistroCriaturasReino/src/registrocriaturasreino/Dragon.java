package registrocriaturasreino;

public class Dragon extends Criatura implements Entrenable {
    private final int potenciaFuego;

    public Dragon(String nombre, String region, NivelMagia nivelMagia, int potenciaFuego) {
        super(nombre, region, nivelMagia);
        this.potenciaFuego = potenciaFuego;
    }

    @Override
    public void entrenar() {
        System.out.println(nombre + " está entrenando y aumentando su fuego.");
    }

    @Override
    public void mostrarDatos() {
        super.mostrarDatos();
        System.out.println("Potencia de fuego: " + potenciaFuego);
    }
}