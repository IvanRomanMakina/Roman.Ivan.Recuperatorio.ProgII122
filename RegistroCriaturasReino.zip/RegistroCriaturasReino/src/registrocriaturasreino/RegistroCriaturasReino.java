package registrocriaturasreino;

import java.util.ArrayList;
import java.util.Objects;

public class RegistroCriaturasReino {    
    private final ArrayList<Criatura> criaturas = new ArrayList<>();

    public void agregarCriatura(Criatura c) throws CriaturaException {
        if (c == null) {
            throw new NullCriaturaException();
        }

        String nombre = c.getNombre();
        String region = c.getRegion();
        
        for (Criatura x : criaturas) {
            if (Objects.equals(x.getNombre(), nombre) &&
                Objects.equals(x.getRegion(), region)) {
                throw new CriaturaExistenteException();
            }
        }

        criaturas.add(c);
    }

    public void mostrarCriaturas() {
        for (Criatura c : criaturas) {
            c.mostrarDatos();
            System.out.println("---------------");
        }
    }

    public void entrenarCriaturas() throws CriaturaException {
        for (Criatura c : criaturas) {
            String nombre = c.getNombre();
            if (c instanceof Entrenable e) {
            e.entrenar();
            } else {
                throw new AccionNoPermitidaException(nombre);
            }
        }
    }

    public void regenerarEnergias() throws CriaturaException {
        for (Criatura c : criaturas) {
            String nombre = c.getNombre();
            if (c instanceof Regenerable r) {
            r.regenerarEnergia();
            } else {
                throw new AccionNoPermitidaException(nombre);
            }
        }
    }

    public void filtrarPorNivelDeMagia(NivelMagia nivel) {
        for (Criatura c : criaturas) {
            if (c.getNivelMagia() == nivel) {
                c.mostrarDatos();
                System.out.println("---------------");
            }
        }
    }

    public void filtrarPorTipoDeCriatura(String tipo) {
        for (Criatura c : criaturas) {
            if (c.getClass().getSimpleName().equals(tipo)) {
                c.mostrarDatos();
                System.out.println("---------------");
            }
        }
    }
}