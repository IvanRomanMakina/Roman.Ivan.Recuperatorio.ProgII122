package registrocriaturasreino;

public interface Entrenable {
    void entrenar();
}
