package registrocriaturasreino;

public class CriaturaExistenteException extends CriaturaException {
    public CriaturaExistenteException() {
        super("Ya existe una criatura con ese nombre en esa región.");
    }
}
