package registrocriaturasreino;

public abstract class Criatura {
    protected String nombre;
    protected String region;
    protected NivelMagia nivelMagia;

    public Criatura(String nombre, String region, NivelMagia nivelMagia) {
        this.nombre = nombre;
        this.region = region;
        this.nivelMagia = nivelMagia;
    }

    public String getNombre() {
        return nombre;
    }

    public String getRegion() {
        return region;
    }

    public NivelMagia getNivelMagia() {
        return nivelMagia;
    }

    public void mostrarDatos() {
        System.out.println("Nombre: " + nombre +
                " | Región: " + region +
                " | Nivel de magia: " + nivelMagia);
    }
}
