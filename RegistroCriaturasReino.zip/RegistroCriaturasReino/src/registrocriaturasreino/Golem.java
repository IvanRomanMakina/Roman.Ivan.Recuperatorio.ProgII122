package registrocriaturasreino;

public class Golem extends Criatura implements Regenerable {
    private final int pesoToneladas;

    public Golem(String nombre, String region, NivelMagia nivelMagia, int pesoToneladas) {
        super(nombre, region, nivelMagia);
    if (pesoToneladas < 1 || pesoToneladas > 20) {
        throw new IllegalArgumentException("El peso del gólem debe estar entre 1 y 20 toneladas.");
    }
    this.pesoToneladas = pesoToneladas;
    }

    @Override
    public void regenerarEnergia() {
        System.out.println(nombre + " está recargando energía.");
    }

    @Override
    public void mostrarDatos() {
        super.mostrarDatos();
        System.out.println("Peso (toneladas): " + pesoToneladas);
    }
}

