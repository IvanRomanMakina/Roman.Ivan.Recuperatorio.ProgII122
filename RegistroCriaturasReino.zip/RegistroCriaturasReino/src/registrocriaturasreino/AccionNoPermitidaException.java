package registrocriaturasreino;

public class AccionNoPermitidaException extends CriaturaException {
    public AccionNoPermitidaException(String nombre) {
        super(nombre + " no puede realizar esta acción.");
    }
}