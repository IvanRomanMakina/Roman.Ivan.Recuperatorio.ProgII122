package registrocriaturasreino;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        RegistroCriaturasReino registro = new RegistroCriaturasReino();
        Scanner sc = new Scanner(System.in);
        int opcion = 0;

        while (opcion != 7) {
            System.out.println("\n--- Menú de Criaturas ---");
            System.out.println("1. Agregar Dragón");
            System.out.println("2. Agregar Elfo");
            System.out.println("3. Agregar Gólem");
            System.out.println("4. Mostrar criaturas");
            System.out.println("5. Entrenar criaturas");
            System.out.println("6. Regenerar energías");
            System.out.println("7. Salir");
            System.out.print("Elige una opción: ");
            opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            try {
                switch (opcion) {
                    case 1 -> { // Agregar Dragón
                        System.out.print("Nombre: ");
                        String nombreD = sc.nextLine();
                        System.out.print("Región: ");
                        String regionD = sc.nextLine();
                        System.out.print("Nivel de magia (BAJO, MEDIO, ALTO): ");
                        NivelMagia nivelD = NivelMagia.valueOf(sc.nextLine().toUpperCase());
                        System.out.print("Potencia de fuego: ");
                        int fuego = sc.nextInt();
                        sc.nextLine();
                        registro.agregarCriatura(new Dragon(nombreD, regionD, nivelD, fuego));
                    }
                    case 2 -> { // Agregar Elfo
                        System.out.print("Nombre: ");
                        String nombreE = sc.nextLine();
                        System.out.print("Región: ");
                        String regionE = sc.nextLine();
                        System.out.print("Nivel de magia (BAJO, MEDIO, ALTO): ");
                        NivelMagia nivelE = NivelMagia.valueOf(sc.nextLine().toUpperCase());
                        System.out.print("Habilidad especial: ");
                        String hab = sc.nextLine();
                        registro.agregarCriatura(new Elfo(nombreE, regionE, nivelE, hab));
                    }
                    case 3 -> { // Agregar Gólem
                        System.out.print("Nombre: ");
                        String nombreG = sc.nextLine();
                        System.out.print("Región: ");
                        String regionG = sc.nextLine();
                        System.out.print("Nivel de magia (BAJO, MEDIO, ALTO): ");
                        NivelMagia nivelG = NivelMagia.valueOf(sc.nextLine().toUpperCase());
                        System.out.print("Peso (1-20 toneladas): ");
                        int peso = sc.nextInt();
                        sc.nextLine();
                        registro.agregarCriatura(new Golem(nombreG, regionG, nivelG, peso));
                    }
                    case 4 -> registro.mostrarCriaturas();
                    case 5 -> registro.entrenarCriaturas();
                    case 6 -> registro.regenerarEnergias();
                    case 7 -> System.out.println("Saliendo...");
                    default -> System.out.println("Opción inválida");
                }
            } catch (CriaturaException e) {
                System.out.println(e.getMessage());
            }
        }

        sc.close();
    }
    }