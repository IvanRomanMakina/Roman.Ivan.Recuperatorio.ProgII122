package registrocriaturasreino;

public class NullCriaturaException extends CriaturaException {
    public NullCriaturaException() {
        super("La criatura no puede ser nula.");
    }
}
