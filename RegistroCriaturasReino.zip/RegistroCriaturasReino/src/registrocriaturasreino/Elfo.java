package registrocriaturasreino;

public class Elfo extends Criatura implements Entrenable, Regenerable {
    private final String habilidadEspecial;

    public Elfo(String nombre, String region, NivelMagia nivelMagia, String habilidadEspecial) {
        super(nombre, region, nivelMagia);
        this.habilidadEspecial = habilidadEspecial;
    }

    @Override
    public void entrenar() {
        System.out.println(nombre + " está entrenando su habilidad especial.");
    }

    @Override
    public void regenerarEnergia() {
        System.out.println(nombre + " está regenerando energía.");
    }

    @Override
    public void mostrarDatos() {
        super.mostrarDatos();
        System.out.println("Habilidad especial: " + habilidadEspecial);
    }
}
