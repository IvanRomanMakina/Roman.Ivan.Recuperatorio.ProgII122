package registrocriaturasreino;

public interface Regenerable {
    void regenerarEnergia();
}
